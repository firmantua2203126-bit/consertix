@extends('layouts.app')

@section('content')
<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 text-gray-900">
                <h1 class="text-2xl font-bold text-red-600">🎤 EO Dashboard</h1>
                <p class="mt-2">Hai, EO! Kelola event dan tiketmu di sini.</p>
                <div class="mt-4">
                    <a href="#" class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700">+ Buat Event Baru</a>
                </div>
                <div class="mt-6">
                    <h3 class="font-semibold">Event Kamu:</h3>
                    <ul class="mt-2 space-y-2">
                        <li class="border-l-4 border-red-500 pl-2">Konser Tulus 2025 (1 tiket terjual)</li>
                        <li class="border-l-4 border-gray-300 pl-2">Festival Musik Indie (0 tiket)</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection