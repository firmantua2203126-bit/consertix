@extends('layouts.app')

@section('content')
<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 text-gray-900">
                <h1 class="text-2xl font-bold text-green-600">🎫 User Dashboard</h1>
                <p class="mt-2">Halo! Lihat event menarik dan riwayat pembelianmu di sini.</p>
                <div class="mt-6">
                    <h3 class="font-semibold">Tiket Terbeli:</h3>
                    <ul class="mt-2 space-y-2">
                        <li class="border-l-4 border-green-500 pl-2">Konser Tulus 2025 — VIP + Festival (Lunas)</li>
                    </ul>
                </div>
                <div class="mt-6">
                    <a href="#" class="text-blue-600 hover:underline">Jelajahi Event Lain →</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection