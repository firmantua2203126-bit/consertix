<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Concertix – Pemesanan Tiket Konser</title>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        body {
            background: linear-gradient(135deg, #fdfdfd 0%, #f8f9fa 100%);
        }
        .hero-bg {
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)),
                        url('https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80');
            background-size: cover;
            background-position: center;
        }
    </style>
</head>
<body class="font-sans antialiased">

    <!-- Header dengan Login/Register -->
    <header class="absolute top-0 right-0 z-10 w-full">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-end">
            <?php if(Route::has('login')): ?>
                <nav class="flex items-center space-x-4">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/dashboard')); ?>"
                           class="px-4 py-2 bg-white text-gray-800 rounded-md font-medium hover:bg-gray-100 transition">
                           Dashboard
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>"
                           class="px-4 py-2 bg-white text-gray-800 rounded-md font-medium hover:bg-gray-100 transition">
                           Login
                        </a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>"
                               class="px-4 py-2 bg-indigo-600 text-white rounded-md font-medium hover:bg-indigo-700 transition">
                               Register
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </nav>
            <?php endif; ?>
        </div>
    </header>

    <!-- Hero Section -->
    <div class="hero-bg min-h-screen flex items-center justify-center text-center text-white">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <h1 class="text-4xl md:text-6xl font-bold mb-6 drop-shadow-lg">
                Selamat Datang di <span class="text-indigo-300">Concertix</span>
            </h1>
            <p class="text-lg md:text-xl mb-10 max-w-2xl mx-auto drop-shadow">
                Platform pemesanan tiket konser terpercaya. Temukan event favoritmu dan dapatkan pengalaman konser tak terlupakan!
            </p>

            <?php if(auth()->guard()->guest()): ?>
                <div class="space-x-4">

                    <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>"
                       class="inline-block px-6 py-3 bg-green-600 hover:bg-green-700 rounded-lg font-semibold transition">
                        Daftar sebagai User
                    </a>
                    <?php endif; ?>

                    <?php if(Route::has('login')): ?>
                    <a href="<?php echo e(route('login')); ?>"
                       class="inline-block px-6 py-3 bg-white text-gray-800 hover:bg-gray-100 rounded-lg font-semibold transition">
                        Login
                    </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Info Cards -->
    <section class="py-16 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900">Mengapa Memilih Concertix?</h2>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="p-6 border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition">
                    <h3 class="text-xl font-semibold text-indigo-700 mb-2">Mudah & Cepat</h3>
                    <p class="text-gray-600">Proses pemesanan hanya dalam 3 langkah. Tiket langsung dikirim ke emailmu.</p>
                </div>
                <div class="p-6 border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition">
                    <h3 class="text-xl font-semibold text-indigo-700 mb-2">Event Terlengkap</h3>
                    <p class="text-gray-600">Ratusan event konser dari berbagai genre, selalu update setiap minggu.</p>
                </div>
                <div class="p-6 border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition">
                    <h3 class="text-xl font-semibold text-indigo-700 mb-2">Aman & Terpercaya</h3>
                    <p class="text-gray-600">Pembayaran aman, tiket 100% garansi asli, dan layanan pelanggan 24/7.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <p>&copy; <?php echo e(date('Y')); ?> Concertix. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>
<?php /**PATH C:\laragon\www\consertix\resources\views/welcome.blade.php ENDPATH**/ ?>